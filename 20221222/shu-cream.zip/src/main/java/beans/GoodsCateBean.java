package beans;

public class GoodsCateBean {

	private String gs_Big;
	private String gs_Small;
	
	
	
	public String getGs_Big() {
		return gs_Big;
	}
	public void setGs_Big(String gs_Big) {
		this.gs_Big = gs_Big;
	}
	public String getGs_Small() {
		return gs_Small;
	}
	public void setGs_Small(String gs_Small) {
		this.gs_Small = gs_Small;
	}
	
}
