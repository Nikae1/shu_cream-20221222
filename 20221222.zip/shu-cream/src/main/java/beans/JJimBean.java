package beans;

public class JJimBean {

}
