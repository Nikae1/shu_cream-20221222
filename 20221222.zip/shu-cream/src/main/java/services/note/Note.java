package services.note;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import beans.ActionBean;
import beans.CategoriesBean;
import beans.NoteBean;
import beans.UserBean;

public class Note {
	private HttpServletRequest request;
	private HttpSession session;
	
	public Note(HttpServletRequest request){
		this.request = request;
		session = this.request.getSession();
	}
	
	
	public ActionBean backcontroller(int serviceCode) {
		ActionBean action = null;
		
		if(serviceCode == 21) {
			action = this.NoteInsCtl();
		}else if(serviceCode == 22) {
			action = this.NoteSelCtl();   
		}
		return action;
	}
	
	/* 아이디를 사용하여 게시물을 검색하여 가지고 오기위한 Ctl */
	private ActionBean NoteSelCtl() {
		ActionBean action = new ActionBean();
		UserBean user = new UserBean();
		ArrayList<UserBean> userList = new ArrayList<UserBean>();
		String page = "RegistPage.jsp", message = null;
		boolean access = true;
		
		user.setUserId(this.request.getParameter("UserId"));
		
		NoteDataAccessObject dao = new NoteDataAccessObject();
		Connection connection = dao.openConnection();
		
		if(this.request.getParameter("UserId") != null) {
			
			userList = dao.selNote(connection, user);
			session.setAttribute("Note", userList);
			
			access = false;
			page = "RegistPage.jsp"; 
			
		}else {
			
			access = true;
			page = "index.jsp"; 
			
			message = "입력하신 아이디의 게시물이 존재하지 않습니다..";
			
			try {
				message = ("?message=")+URLEncoder.encode(message, "UTF-8");
			} catch (UnsupportedEncodingException e) {e.printStackTrace();}
			
		}
		
		dao.closeConnection(connection);
		
		action.setPage(page);
		action.setRedirect(access);
		
		return action;
	}
	
	
	
	
	/* note 테이블에 data를 insert하기위한 메소드 */
	private ActionBean NoteInsCtl() {
		ActionBean action = new ActionBean();
		UserBean user = new UserBean();
		ArrayList<UserBean> userList = null;
		NoteBean note = new NoteBean(); 
		String page, message = null;
		boolean tran = false, access = true;
		
		note.setConntents(this.request.getParameter("conntents"));
		note.setGoodsName(this.request.getParameter("goodsName"));
		note.setGoodsPrice(this.request.getParameter("goodsPrice"));
		note.setGoodsQuantity(this.request.getParameter("goodsQuantity"));
		note.setGoodsState(this.request.getParameter("goodsState")); // 상품상태
		note.setNoteIng("T01");
		
		// 판매중 , 판매완료 등
//		if(this.request.getParameter("NoteIng").equals("판매중")) note.setNoteIng("T01");
//	    else if(this.request.getParameter("NoteIng").equals("구매중")) note.setNoteIng("T00");
//		else if(this.request.getParameter("NoteIng").equals("판매완료")) note.setNoteIng("T02");
//		else note.setNoteIng("T03");
		
		//삽니다 , 팝니다
		if(this.request.getParameter("noteState").equals("삽니다")) note.setNoteState("T04");
		else note.setNoteState("T05");
		
		//택배 , 직거래
		if(this.request.getParameter("tranMethod").equals("택배")) note.setTranMethod("TM1");
		else note.setTranMethod("TM2");
		note.setNoteImage(this.request.getParameter("noteImage") == null ? null : this.request.getParameter("NoteImage"));
		note.setNoteCode("000000001");
		
		ArrayList<NoteBean> noteList = new ArrayList<NoteBean>();
		noteList.add(note);
		user.setNoteList(noteList);
		user.setUserId(this.request.getParameter("userId"));
		userList = new ArrayList<UserBean>();
		
		NoteDataAccessObject dao = new NoteDataAccessObject();
		Connection connection = dao.openConnection();
		dao.modifyTranStatus(connection, tran);
		
		//dao.getMaxNoteCode(connection, userList);
		
		if(this.convertToBoolean(dao.insNote(connection, user))) {
			System.out.println("NoteInsCtl");
			
			/* 입력한 내용을 client로 보내어 보여주기위한 */
			userList = dao.selNote(connection, user);
			tran = true;
			access = false;
			page = "RegistPage.jsp";
			
			request.setAttribute("NoteList", userList);
			
		}else {
			page = "RegistPage.jsp";
			message = "게시판의 양식과 다릅니다.";
			
			try {
				message = ("?message=")+URLEncoder.encode(message, "UTF-8");
			} catch (UnsupportedEncodingException e) {e.printStackTrace();}
		}
		
		dao.setTransaction(tran, connection);
		dao.modifyTranStatus(connection, tran);
		dao.closeConnection(connection);
		
		
		action.setPage(page);
		action.setRedirect(access);
		
		return action;
	}
	
	private boolean convertToBoolean(int value) {
		return value>0? true:false;
	}
	
}